# Pretty Spa — Website Concept

A polished, responsive static website concept for Pretty Spa, 1134 Targee St, Staten Island, NY 10304.

## Publish on GitHub Pages

1. Create a **new public GitHub repository** named `pretty-spa` (do not use an unrelated existing repo).
2. Upload `index.html`, `styles.css`, and `script.js` to the repository root.
3. Go to **Settings → Pages → Build and deployment**. Select **Deploy from a branch**, `main`, `/(root)`, then Save.
4. Visit `https://YOUR-USERNAME.github.io/pretty-spa/` once GitHub finishes publishing.

## Verify before presenting as the official business website

- Get the spa owner's approval to publish a site using their name.
- Confirm phone number **(929) 730-6665** and address **1134 Targee St, Staten Island, NY 10304**.
- Confirm current operating hours; screenshot says open and closes 11PM, **not sufficient to establish daily hours**.
- Replace illustrated services with an approved real service menu, prices, descriptions, and booking method.
- Replace external stock photography with licensed photos of the real spa.
- Google rating (4.0 / 5, 22 reviews) is **from the screenshot** and may become outdated; update or remove it.
- Remove the “website concept” notice only with business authorization.

## Features
Responsive navigation, landing page, service inquiry cards, about section, review link, phone CTA, directions link, embedded map, footer and SEO basics. No backend, payments, or online appointment booking is configured; booking CTAs open the phone dialer.

Photos are loaded from Unsplash URLs; Google Fonts and embedded map need internet access.


## Hours and service pricing update
The supplied Google listing shows Pretty Spa open daily from 10:00 AM to 11:00 PM.
The service cards intentionally say pricing is available by phone because no verified
price list was provided. Replace the illustrative service categories and pricing labels
with the business’s actual menu before promoting the site as an official menu.
No online booking system is included.
